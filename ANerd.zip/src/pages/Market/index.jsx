import React from "react";
import MarketPlace from "../../components/Marketplace";
import "./style.css";
const Market = () => {
  return (
    <>
      <div className="main-bg">
        <MarketPlace />
      </div>
    </>
  );
};

export default Market;
