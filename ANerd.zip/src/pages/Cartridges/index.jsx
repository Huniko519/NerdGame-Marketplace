import React from "react";
import Nft from "../../components/Cartridges";

const Cartridges = () => {
  return (
    <>
      <Nft />
    </>
  );
};

export default Cartridges;
