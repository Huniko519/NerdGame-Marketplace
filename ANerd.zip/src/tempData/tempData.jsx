import gameImg1 from '../assets/game1.svg';
import gameImg2 from '../assets/img2.svg';
import gameImg3 from '../assets/gameImg1.svg';
import gameImg4 from '../assets/gameImg2.svg';
import usrAvatar from '../assets/girl.svg';

const itemData = [
    {
        gameName: 'Top NFT’s',
        gameImg: gameImg1,
        place_bid: 'Place a bid',
        usrAvatar:  usrAvatar ,
        msg: 'Origin and Evolution#4477',
        UserName: '@miriamammi',
        Amount: '0.99 ETH',
        time: '4d 16h 32m 10s',
    },
    {
        gameName: 'Top NFT’s',
        gameImg: gameImg2 ,
        place_bid: 'Place a bid',
        usrAvatar: usrAvatar,
        msg: 'Origin and Evolution#4477',
        UserName: '@miriamammi',
        Amount: '0.99 ETH',
        time: '4d 16h 32m 10s',
    },
    {
        gameName: 'Top NFT’s',
        gameImg: gameImg3,
        place_bid: 'Place a bid',
        usrAvatar: usrAvatar,
        msg: 'Origin and Evolution#4477',
        UserName: '@miriamammi',
        Amount: '0.99 ETH',
        time: '4d 16h 32m 10s',
    },
    {
        gameName: 'Top NFT’s',
        gameImg:  gameImg4 ,
        place_bid: 'Place a bid',
        usrAvatar: usrAvatar,
        msg: 'Origin and Evolution#4477',
        UserName: '@miriamammi',
        Amount: '0.99 ETH',
        time: '4d 16h 32m 10s',
    },

    {
        gameName: 'Top NFT’s',
        gameImg: gameImg1,
        place_bid: 'Place a bid',
        usrAvatar: usrAvatar,
        msg: 'Origin and Evolution#4477',
        UserName: '@miriamammi',
        Amount: '0.99 ETH',
        time: '4d 16h 32m 10s',
    },
    {
        gameName: 'Top NFT’s',
        gameImg: gameImg2 ,
        place_bid: 'Place a bid',
        usrAvatar: usrAvatar,
        msg: 'Origin and Evolution#4477',
        UserName: '@miriamammi',
        Amount: '0.99 ETH',
        time: '4d 16h 32m 10s',
    },
    {
        gameName: 'Top NFT’s',
        gameImg:  gameImg3 ,
        place_bid: 'Place a bid',
        usrAvatar: usrAvatar,
        msg: 'Origin and Evolution#4477',
        UserName: '@miriamammi',
        Amount: '0.99 ETH',
        time: '4d 16h 32m 10s',
    },
    {
        gameName: 'Top NFT’s',
        gameImg: gameImg4 ,
        place_bid: 'Place a bid',
        usrAvatar: usrAvatar,
        msg: 'Origin and Evolution#4477',
        UserName: '@miriamammi',
        Amount: '0.99 ETH',
        time: '4d 16h 32m 10s',
    },
];

export default itemData;

